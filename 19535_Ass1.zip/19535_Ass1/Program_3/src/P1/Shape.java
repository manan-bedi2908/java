/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P1;

/**
 *
 * @author WINDOWS 10
 */
public abstract class Shape {
    public abstract void area();
    
    @Override
    public abstract String toString();
    
    public abstract void input();   
}
